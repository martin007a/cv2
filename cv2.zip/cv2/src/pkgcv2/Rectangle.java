package pkgcv2;

public class Rectangle {
    static int instanceCount;
    private int a,b;

    private Rectangle(int a, int b) {
        this.a = a;
        this.b = b;
        instanceCount++;
    }

    public int getArea() {
        return this.a * this.b;
    }

    public int getPerimeter() {
        return 2*(a + b);
    }

    static int getInstanceCount() {
        return instanceCount;
    }

    static Rectangle getInstance(int a, int b) {
        if(a >0 && b > 0) return new Rectangle(a,b);
        return null;
    }

    static Rectangle getInstance(int a) {
       return getInstance(a,a);
    }

    static Rectangle getInstance() {
        return new Rectangle(3,5);
    }



}
