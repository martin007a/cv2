package pkgcv2;

import java.io.Console;

public class Backpack {
    private final int volume;
    private final int loadCapacity;
    private int remainingLoadCapacity;
    private int remainingVolume;

    Backpack(int volume, int loadCapacity) {
        this.volume = remainingVolume = volume;
        this.loadCapacity = remainingLoadCapacity = loadCapacity;
    }

    public boolean putItem(Item item) {
        int itemWeight = item.getWeight();
        int itemVolume = item.getVolume();

        if (item == null) return false;

        if(this.remainingLoadCapacity>= itemWeight
                && this.remainingVolume >= itemVolume) {
            remainingLoadCapacity -= itemWeight;
            remainingVolume -= itemVolume;
            return true;
        } else {
            return false;
        }

    }

    public int getVolume() {
        return volume;
    }

    public int getLoadCapacity() {
        return loadCapacity;
    }

    public int getRemainingLoadCapacity() {
        return remainingLoadCapacity;
    }

    public int getRemainingVolume() {
        return remainingVolume;
    }

}
