package pkgcv2;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public  static void main(String[] args) {
        Backpack backpack = new Backpack(10, 10);
        Item item1 = new Item(5,4);
        Item item2 = new Item(5,5);
        Item item3 = new Item(1,1);

        System.out.println(backpack.putItem(item1));
        System.out.println(backpack.putItem(item3));
        System.out.println(backpack.putItem(item2));

        System.out.println(Rectangle.getInstanceCount());
        Rectangle.getInstance();
        Rectangle.getInstance(8);
        Rectangle.getInstance(6,-7);
        System.out.println(Rectangle.getInstanceCount());

    }
}